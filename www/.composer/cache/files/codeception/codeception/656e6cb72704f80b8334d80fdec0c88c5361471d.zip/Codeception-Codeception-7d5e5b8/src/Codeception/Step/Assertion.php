<?php

declare(strict_types=1);

namespace Codeception\Step;

use Codeception\Step as CodeceptionStep;

class Assertion extends CodeceptionStep
{
}
