import "./bundle";
import Colormask from "./lib/extensions/colormask";
export default Colormask;
