Установка
=========

## Получение расширения через Composer

Предпочтительный способ установки расширения - через [Composer](https://getcomposer.org/download/).

Для этого запустите команду

```
php composer.phar require --prefer-dist yiisoft/yii2-bootstrap5
```

или добавьте

```
"yiisoft/yii2-bootstrap5": "~2.0.0"
```

в секцию **require** вашего `composer.json`.
